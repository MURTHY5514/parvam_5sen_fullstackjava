package com.springbootgamingclubproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootgamingclubproject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
